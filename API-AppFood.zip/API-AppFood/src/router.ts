// O código começa importando os módulos necessários, como path (para manipulação de caminhos de arquivo), Router do Express (para criar rotas), multer (para o upload de arquivos), e várias funções de casos de uso relacionadas a categorias, produtos e pedidos.
import path from 'node:path';
import { Router } from 'express';
import multer from 'multer';
import { listCategories } from './app/useCases/categories/listCategories';
import { createCategory } from './app/useCases/categories/createCategory';
import { listProducts } from './app/useCases/products/listProducts';
import { createProduct } from './app/useCases/products/createProduct';
import { listProductsByCategory } from './app/useCases/categories/listProductsByCategory';
import { listOrders } from './app/useCases/orders/listOrders';
import { createOrder } from './app/useCases/orders/createOrder';
import { changeOrderStatus } from './app/useCases/orders/changeOrderStatus';
import { cancelOrder } from './app/useCases/orders/cancelOrder';
export const router = Router();

//configuração do multer
const upload = multer({ // O objeto upload é configurado para lidar com o upload de arquivos. Ele usa o multer.diskStorage para especificar onde os arquivos enviados devem ser armazenados e como devem ser nomeados.
	storage: multer.diskStorage({
		destination(req, file, callback){
			callback(null, path.resolve(__dirname, '..', 'uploads'));
		},
		filename(req, file, callback){
			callback(null, `${Date.now()}-${file.originalname}`);
		},
	})

});

//List categories
router.get('/categories', listCategories); // Rota GET para listar todas as categorias. Usa a função listCategories como manipulador.

//Create category
router.post('/categories', createCategory); // Rota POST para criar uma nova categoria. Usa a função createCategory como manipulador.

//List products
router.get('/products', listProducts); // Rota GET para listar todos os produtos. Usa a função listProducts como manipulador.

//Create products
router.post('/products', upload.single('image'), createProduct);// Rota POST para criar um novo produto com a capacidade de fazer upload de uma imagem. Usa a função createProduct como manipulador e utiliza o middleware upload.single('image') para lidar com o upload da imagem.

//Get products by category
router.get('/categories/:categoryId/products', listProductsByCategory); // Rota GET para listar produtos por categoria. Usa a função listProductsByCategory como manipulador e usa o parâmetro categoryId da URL para filtrar os produtos pela categoria especificada.

//List orders
router.get('/orders', listOrders); // Rota GET para listar todos os pedidos. Usa a função listOrders como manipulador.

//Create orders
router.post('/orders', createOrder); // Rota POST para criar um novo pedido. Usa a função createOrder como manipulador.

//Change orders status/ patch e nao put por ser uma alteração parcial
router.patch('/orders/:orderId', changeOrderStatus); //  Rota PATCH para alterar o status de um pedido específico. Usa a função changeOrderStatus como manipulador e usa o parâmetro orderId da URL para identificar o pedido a ser modificado.

//Delete/cancel order
router.delete('/orders/:orderId', cancelOrder); // Rota DELETE para cancelar um pedido específico. Usa a função cancelOrder como manipulador e usa o parâmetro orderId da URL para identificar o pedido a ser cancelado.