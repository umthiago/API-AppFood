// O código começa importando os módulos Request e Response do Express. Esses módulos são usados para lidar com objetos de solicitação HTTP (Request) e objetos de resposta HTTP (Response).
import { Request, Response } from 'express';
import { Category } from '../../models/Category';

export async function createCategory(req: Request, res: Response) { // controlador responsável por criar uma nova categoria quando uma solicitação POST é feita para a rota associada a esta função.
	// A função é definida dentro de um bloco try-catch para lidar com erros potenciais que possam ocorrer durante o processo de criação da categoria;
	try {
		//res.send('Ok post category');
		const {icon, name} = req.body; // Pega os dados do corpo da requisição
		const category = await Category.create({icon, name}); 

		res.status(201).json(category); // Responde com a categoria criada em formato JSON

	} catch (error) { 

		console.log(error);  // Registra erros no console
		res.sendStatus(500); 
	}
}