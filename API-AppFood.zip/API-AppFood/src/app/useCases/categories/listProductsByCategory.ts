// O código começa importando os módulos Request e Response do Express. Esses módulos são usados para lidar com objetos de solicitação HTTP (Request) e objetos de resposta HTTP (Response)
import { Request, Response } from 'express';
import { Product } from '../../models/Product';

export async function listProductsByCategory(req: Request, res: Response) { // controlador responsável por buscar e listar todos os produtos de uma categoria específica quando uma solicitação GET é feita para a rota associada a esta função
	// A função é definida dentro de um bloco try-catch para lidar com erros potenciais que possam ocorrer durante o processo de listagem dos produtos da categoria
	try {
		const {categoryId} = req.params; // extrai o valor do parâmetro categoryId da URL da solicitação. Este parâmetro é usado para filtrar os produtos com base na categoria especificada

		const products = await Product.find().where('category').equals(categoryId); // realiza uma consulta ao banco de dados MongoDB usando o modelo Product.

		res.json(products); // Se a consulta for bem-sucedida e produtos forem encontrados na categoria especificada, a função responde com um status HTTP 200 (OK) e envia a lista de produtos como uma resposta JSON
	} catch (error) { // Se ocorrer algum erro durante o processo de consulta dos produtos, ele é capturado pelo bloco catch.
		console.log(error); // o erro é registrado no console
		res.sendStatus(500); // responde com um status HTTP 500 (Internal Server Error) 
	}

}