// O código começa importando os módulos Request e Response do Express. Esses módulos são usados para lidar com objetos de solicitação HTTP (Request) e objetos de resposta HTTP (Response).

import { Request, Response } from 'express';
import { Order } from '../../models/Order';

export async function listOrders(req: Request, res: Response) { // responsável por buscar e listar todos os pedidos quando uma solicitação GET é feita para a rota associada a esta função.
	// A função é definida dentro de um bloco try-catch para lidar com erros potenciais que possam ocorrer durante o processo de listagem dos pedidos.
	try { 
		const orders = await Order.find() // realiza uma consulta ao banco de dados MongoDB usando o modelo Order.
			.sort({creatAt: 1}) // ordena-os pelo campo createdAt em ordem crescente (1 indica ordem ascendente)
			.populate('products.product'); // utiliza o método populate para preencher as informações dos produtos associados a cada pedido.

		res.json(orders); // Se a consulta for bem-sucedida e pedidos forem encontrados, a função responde com um status HTTP 200 (OK) e envia a lista de pedidos como uma resposta JSON 
	} catch (error) { // Se ocorrer algum erro durante o processo de consulta dos pedidos, ele é capturado pelo bloco catch. 
		console.log(error); // O erro é registrado no console
		res.sendStatus(500); // a função responde com um status HTTP 500 (Internal Server Error) 
	}

}