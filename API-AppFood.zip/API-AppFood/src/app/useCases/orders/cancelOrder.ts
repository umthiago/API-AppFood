// O código começa importando os módulos Request e Response do Express. Esses módulos são usados para lidar com objetos de solicitação HTTP (Request) e objetos de resposta HTTP (Response)
import { Request, Response } from 'express';
import { Order } from '../../models/Order';

export async function cancelOrder(req: Request, res: Response) { // controlador responsável por cancelar um pedido específico quando uma solicitação DELETE é feita para a rota associada a esta função
	// A função é definida dentro de um bloco try-catch para lidar com erros potenciais que possam ocorrer durante o processo de cancelamento do pedido
	try {
		const { orderId } = req.params; // extrai o valor do parâmetro orderId da URL da solicitação. Este parâmetro é usado para identificar o pedido que deve ser cancelado
		await Order.findByIdAndDelete(orderId); // realiza uma consulta ao banco de dados MongoDB, encontra o pedido com o ID correspondente ao orderId especificado na solicitação e o exclui do banco de dados.
		res.sendStatus(204); // Se o pedido for encontrado e excluído com sucesso, a função responde com um status HTTP 204 (No Content), que indica que a solicitação foi bem-sucedida e não há conteúdo para ser retornado.

	} catch (error) { // Se ocorrer algum erro durante o processo de cancelamento do pedido, ele é capturado pelo bloco catch.
		console.log(error); // O erro é registrado no console 
		res.sendStatus(500); // função responde com um status HTTP 500 (Internal Server Error) 
	}
}