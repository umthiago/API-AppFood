// O código começa importando os módulos Request e Response do Express. Esses módulos são usados para lidar com objetos de solicitação HTTP (Request) e objetos de resposta HTTP (Response).
import { Request, Response } from 'express';
import { Order } from '../../models/Order';

export async function changeOrderStatus(req: Request, res: Response) { // controlador responsável por atualizar o status de um pedido quando uma solicitação PATCH é feita para a rota associada a esta função.
	// A função é definida dentro de um bloco try-catch para lidar com erros potenciais que possam ocorrer durante o processo de atualização do status do pedido.
	try {
		// extraem o valor do parâmetro orderId da URL da solicitação e o valor do campo status do corpo da solicitação, respectivamente.
		const { orderId } = req.params;
		const { status } = req.body;

		if (!['WAITING', 'IN_PRODUCTION', 'DONE'].includes(status)){ // verifica se o valor de status fornecido na solicitação está entre as opções válidas 
			return res.status(400).json({ // Se não estiver, a função responde com um status HTTP 400 (Bad Request) e envia uma resposta JSON com uma mensagem de erro.
				error: 'Status should be one of these: WAITING, IN_PRODUCTION, DONE'
			});
		}
		await Order.findByIdAndUpdate(orderId, { status }); // realiza uma consulta ao banco de dados MongoDB. Isso atualiza o status do pedido. 
		res.sendStatus(204); // Se a atualização do status do pedido for bem-sucedida, a função responde com um status HTTP 204 (No Content), indicando que a solicitação foi bem-sucedida e não há conteúdo para ser retornado.
	} catch (error) { // Se ocorrer algum erro durante o processo de atualização do status do pedido, ele é capturado pelo bloco catch.
		console.log(error); // O erro é registrado no console
		res.sendStatus(500); // função responde com um status HTTP 500 (Internal Server Error)
	}
}