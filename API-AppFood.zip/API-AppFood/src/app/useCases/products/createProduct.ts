// O código começa importando os módulos Request e Response do Express. Esses módulos são usados para lidar com objetos de solicitação HTTP (Request) e objetos de resposta HTTP (Response).
import { Request, Response } from 'express';
import { Product } from '../../models/Product';

export async function createProduct(req: Request, res: Response) { // esponsável por criar um novo produto quando uma solicitação POST é feita para a rota associada a esta função.
	// A função é definida dentro de um bloco try-catch para lidar com erros potenciais que possam ocorrer durante o processo de criação do produto.
	try {
		const imagePath = req.file?.filename; // extrai o nome do arquivo de imagem enviado como parte da solicitação. 
		const { name, description, price, category, ingredients } = req.body;

		const product = await Product.create({ // o modelo de dados previamente definido. Os valores extraídos da solicitação são passados como argumentos para criar um novo produto no banco de dados.
			name,
			description,
			imagePath,
			price: Number(price),
			category,
			ingredients:ingredients ? JSON.parse(ingredients): [],
		});

		res.status(201).json(product); // Se o produto for criado com sucesso, a função responde com um status HTTP 201 (Created) e envia o produto criado como uma resposta JSON 
	} catch (error) { // Se ocorrer algum erro durante o processo de criação do produto, ele é capturado pelo bloco catch.
		console.log(error); // O erro é registrado no console
		res.sendStatus(500); // a função responde com um status HTTP 500 (Internal Server Error) 
	}
}