// O código começa importando os módulos necessários do Mongoose, que é uma biblioteca do Node.js para modelagem de dados e interação com o MongoDB.
import {model, Schema } from 'mongoose';


// Cria um modelo de dados chamado 'Product' para produtos
export const Product = model('Product', new Schema({ // define um modelo de dados para um produto.
	name: { // armazena o nome do produto
		type: String,
		required: true,
	},
	description: { // armazena uma descrição do produto
		type: String,
		required: true,
	},
	imagePath: { // armazena o caminho da imagem associada ao produto
		type: String,
		required: true,
	},
	price: { // armazena o preço do produto
		type: Number,
		required: true,
	},
	ingredients: { // contém uma lista de ingredientes do produto
		required: true,
		type:[{
			name: { // armazena o nome do ingrediente 
				type: String,
				required: true,
			},
			icon: { // armazena o ícone do ingrediente
				type: String,
				required: true,
			},
		}],
	},
	category: { // é uma referência a uma categoria no banco de dados, representada pelo seu ID (ObjectID)
		type: Schema.Types.ObjectId,
		required: true,
		ref: 'Category',
	},
}));