// O código começa importando os módulos necessários do Mongoose, que é uma biblioteca do Node.js para modelagem de dados e interação com o MongoDB.
import {model, Schema } from 'mongoose';


// Cria um modelo de dados chamado 'Order' para pedidos
export const Order = model('Order', new Schema({ // A constante Order é criada usando o método model do Mongoose. Isso define um modelo de dados para um pedido.
	// definindo a estrutura do pedido:
	table: { // é um campo do pedido, que é do tipo String e é obrigatório (required: true). Ele armazena informações sobre a mesa à qual o pedido está associado.
		type: String, // Campo 'table' é do tipo String
		required: true,
	},
	status: { // Ele é restrito a um conjunto de valores específicos usando enum
		type: String,
		enum: ['WAITING', 'IN_PRODUCTION', 'DONE'], // valores permitidos
		default: 'WAITING', // Valor padrão
	},
	creatdAt: { // É um campo que armazena a data e hora em que o pedido foi criado. O tipo é Date, e o valor padrão é definido como a data atual usando Date.now.
		type: Date,
		default: Date.now,
	},
	products: { // É um campo do pedido que contém uma lista de produtos incluídos no pedido. É do tipo Array e obrigatório. 
		required: true,
		type:[{
			product: { // Referência a um produto no banco de dados, representado pelo seu ID
				type: Schema.Types.ObjectId,
				required: true,
				ref: 'Product',
			},
			quantity: { // Armazena a quantidade do produto no pedido. 
				type: Number,
				default: 1,
			},
		}],
	},
}));